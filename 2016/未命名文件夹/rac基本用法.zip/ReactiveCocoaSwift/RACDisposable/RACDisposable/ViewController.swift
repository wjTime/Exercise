//
//  ViewController.swift
//  RACDisposable
//
//  Created by wenjie on 16/8/27.
//  Copyright © 2016年 test. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // 创建信号
        let singel = 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

