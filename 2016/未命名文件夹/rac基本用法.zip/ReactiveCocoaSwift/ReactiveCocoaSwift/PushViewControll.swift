//
//  PushViewControll.swift
//  ReactiveCocoaSwift
//
//  Created by wenjie on 16/8/28.
//  Copyright © 2016年 test. All rights reserved.
//

import UIKit

class PushViewControll: UIViewController {

    
    deinit {
        print("deinit")
    }
    
}
