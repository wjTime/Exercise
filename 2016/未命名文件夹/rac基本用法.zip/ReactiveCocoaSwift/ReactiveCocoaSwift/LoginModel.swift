//
//  LoginModel.swift
//  ReactiveCocoaSwift
//
//  Created by wenjie on 16/9/12.
//  Copyright © 2016年 test. All rights reserved.
//

import UIKit

class LoginModel: NSObject {
    
    var name:String?
    var pwd:String?
    
}
