//
//  swiftmodel.swift
//  ReactiveCocoa
//
//  Created by wenjie on 16/9/10.
//  Copyright © 2016年 test. All rights reserved.
//

import UIKit

class swiftmodel: NSObject {

    var name:String = "hello world"
    override init() {
        super.init()
        
    }
    
}
